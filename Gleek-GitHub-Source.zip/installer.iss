#define AppName "Gleek"
#define AppVersion "1.0.3"
#define AppPublisher "Gleek"

[Setup]
AppId={{ACD042F4-89DA-4B3E-9468-629F04E8A6D3}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher={#AppPublisher}
DefaultDirName={localappdata}\Programs\Gleek
DefaultGroupName={#AppName}
DisableDirPage=no
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
OutputDir=installer
OutputBaseFilename=Gleek-Setup-{#AppVersion}
Compression=lzma
SolidCompression=yes
WizardStyle=modern
UninstallDisplayName={#AppName}

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Additional shortcuts:"; Flags: unchecked

[Files]
Source: "dist\Gleek.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: ".env.example"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{autoprograms}\Gleek"; Filename: "{app}\Gleek.exe"
Name: "{autodesktop}\Gleek"; Filename: "{app}\Gleek.exe"; Tasks: desktopicon

[Run]
Filename: "{app}\Gleek.exe"; Description: "Launch Gleek"; Flags: postinstall nowait skipifsilent
