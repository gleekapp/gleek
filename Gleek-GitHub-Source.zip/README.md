# Gleek

Gleek is a Windows desktop app for account pairing and app-based presence. It does not provide screen sharing, remote control, or command execution. Encrypted messaging is opened in Element/Matrix, not sent through Gleek.

## Shared Supabase project

Gleek is configured to use the project's shared Supabase backend by default, so accounts created by all installations use the same database. No per-user configuration is needed.

For development or an alternate deployment, environment variables or a `.env` file can override the default project settings. Never use a `service_role` or secret key in a client app.

The project owner must run the complete `supabase_roles.sql` script in the Supabase SQL Editor before users can create or sign into accounts. It enables row-level security and grants the app's account-scoped operations only to authenticated users.

## Encrypted chat with Element

Each user needs a separate Matrix account, for example on `matrix.org`. In Gleek's Pairing tab, enter and save your Matrix ID. Paired accounts can then open your Matrix profile and start a conversation in Element. Matrix IDs are self-entered and Gleek does not verify account ownership, so confirm the ID through a trusted channel. Verify the other person's devices using Element's verification flow before sharing sensitive information.

Gleek does not encrypt or relay Element messages. Matrix homeservers still see account and connection metadata, including client IP addresses. Element room deletion is separate from Gleek pairing; Gleek cannot enforce a two-person end-chat confirmation or guarantee deletion from devices, server backups, or logs. This app makes no claim of absolute secrecy or protection from compromised devices.

The legacy Supabase `pairing_messages` table may contain plaintext messages sent by older Gleek versions. The updated SQL revokes the app's access to its plaintext messaging RPCs, but intentionally does not delete historical rows. A Supabase project owner can review and delete those old rows separately if they no longer need them.

## Build the Windows installer

On Windows, install Python 3.12 or newer and Inno Setup 6. From the project directory, create and activate a virtual environment, then run:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r build-requirements.txt
powershell -ExecutionPolicy Bypass -File .\build_windows.ps1
```

The script builds a single-file `Gleek.exe` and packages it into `installer\Gleek-Setup-1.0.3.exe`. The installer defaults to `%LOCALAPPDATA%\Programs\Gleek`, allows choosing another destination folder, creates a Start menu shortcut, and offers an optional desktop shortcut.
