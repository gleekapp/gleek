-- Run once in Supabase Dashboard > SQL Editor.
-- Run the complete updated script again after changes to add pairing presence
-- and Matrix contact links to existing installations.
-- New accounts receive the least-privileged "member" access level.
create table if not exists public.profiles (
    user_id uuid primary key references auth.users (id) on delete cascade,
    access_level text not null default 'member'
        check (access_level in ('member', 'admin', 'owner')),
    device_ids text[] not null default '{}'::text[],
    created_at timestamptz not null default now()
);

alter table public.profiles
    add column if not exists device_ids text[] not null default '{}'::text[];

alter table public.profiles
    add column if not exists pairing_code text
    default lower(substr(replace(gen_random_uuid()::text, '-', ''), 1, 12));

alter table public.profiles
    add column if not exists matrix_user_id text;

update public.profiles
set pairing_code = lower(substr(replace(gen_random_uuid()::text, '-', ''), 1, 12))
where pairing_code is null;

alter table public.profiles
    alter column pairing_code set default
    lower(substr(replace(gen_random_uuid()::text, '-', ''), 1, 12)),
    alter column pairing_code set not null;

create unique index if not exists profiles_pairing_code_unique
    on public.profiles (pairing_code);

alter table public.profiles enable row level security;

drop policy if exists "Users can read their own access level" on public.profiles;
create policy "Users can read their own access level"
    on public.profiles
    for select
    to authenticated
    using ((select auth.uid()) = user_id);

grant select on table public.profiles to authenticated;
revoke insert, update, delete on table public.profiles from anon, authenticated;

create table if not exists public.pairing_requests (
    id uuid primary key default gen_random_uuid(),
    requester_id uuid not null references auth.users (id) on delete cascade,
    recipient_id uuid not null references auth.users (id) on delete cascade,
    status text not null default 'pending'
        check (status in ('pending', 'approved', 'denied', 'cancelled')),
    created_at timestamptz not null default now(),
    check (requester_id <> recipient_id)
);

create unique index if not exists pairing_requests_one_pending_per_pair
    on public.pairing_requests (requester_id, recipient_id)
    where status = 'pending';

create table if not exists public.pairings (
    user_a uuid not null references auth.users (id) on delete cascade,
    user_b uuid not null references auth.users (id) on delete cascade,
    created_at timestamptz not null default now(),
    primary key (user_a, user_b),
    check (user_a < user_b)
);

create table if not exists public.account_presence (
    user_id uuid primary key references auth.users (id) on delete cascade,
    last_seen timestamptz not null default now()
);

create table if not exists public.pairing_messages (
    id uuid primary key default gen_random_uuid(),
    sender_id uuid not null references auth.users (id) on delete cascade,
    recipient_id uuid not null references auth.users (id) on delete cascade,
    message_text text not null check (char_length(message_text) between 1 and 500),
    created_at timestamptz not null default now(),
    check (sender_id <> recipient_id)
);

create index if not exists pairing_messages_conversation_created
    on public.pairing_messages (sender_id, recipient_id, created_at desc);

alter table public.pairing_requests enable row level security;
alter table public.pairings enable row level security;
alter table public.account_presence enable row level security;
alter table public.pairing_messages enable row level security;

drop policy if exists "Users can view their pairing requests"
    on public.pairing_requests;
create policy "Users can view their pairing requests"
    on public.pairing_requests
    for select
    to authenticated
    using ((select auth.uid()) in (requester_id, recipient_id));

grant select on table public.pairing_requests to authenticated;
revoke insert, update, delete on table public.pairing_requests
    from anon, authenticated;
revoke all on table public.pairings from anon, authenticated;
revoke all on table public.account_presence from anon, authenticated;
revoke all on table public.pairing_messages from anon, authenticated;

create or replace function public.request_pairing(target_pairing_code text)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
    current_user_id uuid := auth.uid();
    target_user_id uuid;
    request_id uuid;
begin
    if current_user_id is null then
        raise exception 'Sign in before requesting a pairing.';
    end if;
    if (
        select count(*) from public.pairing_requests as r
        where r.requester_id = current_user_id
          and r.created_at > now() - interval '10 minutes'
    ) >= 5 then
        raise exception 'Too many recent requests. Please try again later.';
    end if;

    select p.user_id into target_user_id
    from public.profiles as p
    where p.pairing_code = lower(trim(target_pairing_code));

    if target_user_id is null then
        raise exception 'No account was found for that pairing code.';
    end if;
    if target_user_id = current_user_id then
        raise exception 'You cannot pair with your own account.';
    end if;
    if exists (
        select 1 from public.pairings as p
        where p.user_a = least(current_user_id, target_user_id)
          and p.user_b = greatest(current_user_id, target_user_id)
    ) then
        raise exception 'These accounts are already paired.';
    end if;
    if exists (
        select 1 from public.pairing_requests as r
        where r.requester_id = current_user_id
          and r.recipient_id = target_user_id
          and r.status = 'pending'
    ) then
        raise exception 'A pairing request is already pending.';
    end if;

    insert into public.pairing_requests (requester_id, recipient_id)
    values (current_user_id, target_user_id)
    returning id into request_id;

    return request_id;
end;
$$;

create or replace function public.respond_to_pairing(
    target_request_id uuid,
    approve boolean
)
returns boolean
language plpgsql
security definer
set search_path = ''
as $$
declare
    current_user_id uuid := auth.uid();
    request_row public.pairing_requests%rowtype;
begin
    if current_user_id is null then
        raise exception 'Sign in before responding to a pairing request.';
    end if;

    select * into request_row
    from public.pairing_requests as r
    where r.id = target_request_id
      and r.recipient_id = current_user_id
      and r.status = 'pending'
    for update;

    if not found then
        raise exception 'This pairing request is no longer pending.';
    end if;

    update public.pairing_requests
    set status = case when approve then 'approved' else 'denied' end
    where id = target_request_id;

    if approve then
        insert into public.pairings (user_a, user_b)
        values (
            least(current_user_id, request_row.requester_id),
            greatest(current_user_id, request_row.requester_id)
        )
        on conflict do nothing;
    end if;

    return true;
end;
$$;

create or replace function public.revoke_pairing(target_user_id uuid)
returns boolean
language plpgsql
security definer
set search_path = ''
as $$
declare
    current_user_id uuid := auth.uid();
    removed_count integer;
begin
    if current_user_id is null then
        raise exception 'Sign in before revoking a pairing.';
    end if;
    if target_user_id = current_user_id then
        raise exception 'Invalid pairing account.';
    end if;

    delete from public.pairings as p
    where p.user_a = least(current_user_id, target_user_id)
      and p.user_b = greatest(current_user_id, target_user_id);
    get diagnostics removed_count = row_count;

    if removed_count = 0 then
        raise exception 'This account is not paired with you.';
    end if;

    return true;
end;
$$;

create or replace function public.get_pairing_state()
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
    current_user_id uuid := auth.uid();
begin
    if current_user_id is null then
        raise exception 'Sign in to view pairing status.';
    end if;

    return jsonb_build_object(
        'requests', coalesce((
            select jsonb_agg(jsonb_build_object(
                'id', r.id,
                'user_id', r.requester_id,
                'email', u.email,
                'created_at', r.created_at
            ) order by r.created_at)
            from public.pairing_requests as r
            join auth.users as u on u.id = r.requester_id
            where r.recipient_id = current_user_id
              and r.status = 'pending'
        ), '[]'::jsonb),
        'outgoing', coalesce((
            select jsonb_agg(jsonb_build_object(
                'id', r.id,
                'user_id', r.recipient_id,
                'email', u.email,
                'created_at', r.created_at
            ) order by r.created_at)
            from public.pairing_requests as r
            join auth.users as u on u.id = r.recipient_id
            where r.requester_id = current_user_id
              and r.status = 'pending'
        ), '[]'::jsonb),
        'pairings', coalesce((
            select jsonb_agg(jsonb_build_object(
                'user_id', case
                    when p.user_a = current_user_id then p.user_b
                    else p.user_a
                end,
                'email', u.email,
                'created_at', p.created_at,
                'matrix_user_id', peer_profile.matrix_user_id,
                'online', coalesce(ap.last_seen > now() - interval '35 seconds', false),
                'last_seen', ap.last_seen
            ) order by u.email)
            from public.pairings as p
            join auth.users as u
              on u.id = case
                  when p.user_a = current_user_id then p.user_b
                  else p.user_a
              end
            left join public.account_presence as ap
              on ap.user_id = case
                  when p.user_a = current_user_id then p.user_b
                  else p.user_a
              end
            left join public.profiles as peer_profile
              on peer_profile.user_id = case
                  when p.user_a = current_user_id then p.user_b
                  else p.user_a
              end
            where current_user_id in (p.user_a, p.user_b)
        ), '[]'::jsonb)
    );
end;
$$;

create or replace function public.set_matrix_user_id(target_matrix_user_id text)
returns boolean
language plpgsql
security definer
set search_path = ''
as $$
declare
    current_user_id uuid := auth.uid();
begin
    if current_user_id is null then
        raise exception 'Sign in before saving a Matrix ID.';
    end if;
    if target_matrix_user_id is not null
       and target_matrix_user_id !~ '^@[A-Za-z0-9._=/-]+:[A-Za-z0-9.-]+(:[0-9]{1,5})?$' then
        raise exception 'Enter a valid Matrix ID, such as @username:matrix.org.';
    end if;

    update public.profiles
    set matrix_user_id = target_matrix_user_id
    where user_id = current_user_id;

    if not found then
        raise exception 'Your Gleek profile was not found.';
    end if;
    return true;
end;
$$;

create or replace function public.update_presence()
returns boolean
language plpgsql
security definer
set search_path = ''
as $$
declare
    current_user_id uuid := auth.uid();
begin
    if current_user_id is null then
        raise exception 'Sign in to update presence.';
    end if;

    insert into public.account_presence (user_id, last_seen)
    values (current_user_id, now())
    on conflict (user_id) do update set last_seen = excluded.last_seen;

    return true;
end;
$$;

create or replace function public.clear_presence()
returns boolean
language plpgsql
security definer
set search_path = ''
as $$
declare
    current_user_id uuid := auth.uid();
begin
    if current_user_id is null then
        raise exception 'Sign in to clear presence.';
    end if;

    delete from public.account_presence as ap
    where ap.user_id = current_user_id;

    return true;
end;
$$;

create or replace function public.send_pairing_message(
    target_user_id uuid,
    message_text text
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
    current_user_id uuid := auth.uid();
    message_id uuid;
    clean_message text := trim(message_text);
begin
    if current_user_id is null then
        raise exception 'Sign in before sending a message.';
    end if;
    if target_user_id = current_user_id then
        raise exception 'You cannot message your own account.';
    end if;
    if clean_message is null
       or char_length(clean_message) < 1
       or char_length(clean_message) > 500 then
        raise exception 'Messages must be between 1 and 500 characters.';
    end if;
    if not exists (
        select 1 from public.pairings as p
        where p.user_a = least(current_user_id, target_user_id)
          and p.user_b = greatest(current_user_id, target_user_id)
    ) then
        raise exception 'You can only message an account paired with you.';
    end if;

    insert into public.pairing_messages (sender_id, recipient_id, message_text)
    values (current_user_id, target_user_id, clean_message)
    returning id into message_id;

    return message_id;
end;
$$;

create or replace function public.get_pairing_messages(target_user_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
    current_user_id uuid := auth.uid();
begin
    if current_user_id is null then
        raise exception 'Sign in to view messages.';
    end if;
    if target_user_id = current_user_id or not exists (
        select 1 from public.pairings as p
        where p.user_a = least(current_user_id, target_user_id)
          and p.user_b = greatest(current_user_id, target_user_id)
    ) then
        raise exception 'You can only view messages for an account paired with you.';
    end if;

    return coalesce((
        select jsonb_agg(jsonb_build_object(
            'id', recent.id,
            'sender_id', recent.sender_id,
            'message_text', recent.message_text,
            'created_at', recent.created_at
        ) order by recent.created_at)
        from (
            select m.id, m.sender_id, m.message_text, m.created_at
            from public.pairing_messages as m
            where (m.sender_id = current_user_id and m.recipient_id = target_user_id)
               or (m.sender_id = target_user_id and m.recipient_id = current_user_id)
            order by m.created_at desc
            limit 100
        ) as recent
    ), '[]'::jsonb);
end;
$$;

revoke all on function public.request_pairing(text) from public, anon;
revoke all on function public.respond_to_pairing(uuid, boolean) from public, anon;
revoke all on function public.revoke_pairing(uuid) from public, anon;
revoke all on function public.get_pairing_state() from public, anon;
revoke all on function public.update_presence() from public, anon;
revoke all on function public.clear_presence() from public, anon;
revoke all on function public.send_pairing_message(uuid, text) from public, anon;
revoke all on function public.get_pairing_messages(uuid) from public, anon;
revoke all on function public.send_pairing_message(uuid, text) from authenticated;
revoke all on function public.get_pairing_messages(uuid) from authenticated;
revoke all on function public.set_matrix_user_id(text) from public, anon;
grant execute on function public.request_pairing(text) to authenticated;
grant execute on function public.respond_to_pairing(uuid, boolean) to authenticated;
grant execute on function public.revoke_pairing(uuid) to authenticated;
grant execute on function public.get_pairing_state() to authenticated;
grant execute on function public.update_presence() to authenticated;
grant execute on function public.clear_presence() to authenticated;
grant execute on function public.set_matrix_user_id(text) to authenticated;

-- Gleek no longer sends readable messages through Supabase; Element handles
-- encrypted chat. Existing pairing_messages rows are deliberately preserved.
create or replace function public.create_profile_for_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
    insert into public.profiles (user_id)
    values (new.id)
    on conflict (user_id) do nothing;
    return new;
end;
$$;

drop trigger if exists create_profile_after_signup on auth.users;
create trigger create_profile_after_signup
    after insert on auth.users
    for each row execute function public.create_profile_for_new_user();

-- Add profiles for accounts that existed before this script was run.
insert into public.profiles (user_id)
select id from auth.users
on conflict (user_id) do nothing;

-- To change an account's access level or assign devices, find its UUID in
-- Authentication > Users, then run one of these in the SQL Editor:
-- update public.profiles
-- set access_level = 'admin'
-- where user_id = '00000000-0000-0000-0000-000000000000';
--
-- Allowed values: 'member', 'admin', 'owner'.
-- Owners see all device IDs listed in main.py. Admins see only assigned IDs.
-- Members see no devices. Pairing only records consent between accounts; it
-- does not enable screen viewing or remote control.
--
-- To promote an account to owner instead:
-- update public.profiles
-- set access_level = 'owner'
-- where user_id = '00000000-0000-0000-0000-000000000000';
--
-- To return an account to member:
-- update public.profiles
-- set access_level = 'member', device_ids = '{}'
-- where user_id = '00000000-0000-0000-0000-000000000000';
--
-- update public.profiles
-- set device_ids = array['Dev-1', 'Dev-2']
-- where user_id = '00000000-0000-0000-0000-000000000000';
--
-- Pairing enables app presence and exposes a user's Matrix ID only to paired
-- accounts. Online means the app checked in within the last 35 seconds; it
-- does not confirm PC power state.
-- Pairing does not enable screen viewing, remote control, or command execution.

notify pgrst, 'reload schema';
