$ErrorActionPreference = "Stop"

$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$python = Join-Path $projectRoot ".venv\Scripts\python.exe"
$innoCompiler = (Get-Command "ISCC.exe" -ErrorAction SilentlyContinue).Source

if (-not $innoCompiler) {
    $innoCandidates = @(
            (Join-Path $env:LOCALAPPDATA "Programs\Inno Setup 6\ISCC.exe"),
            (Join-Path $env:ProgramFiles "Inno Setup 6\ISCC.exe"),
            (Join-Path ${env:ProgramFiles(x86)} "Inno Setup 6\ISCC.exe")
        )
    $innoCompiler = $innoCandidates | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
}

if (-not (Test-Path -LiteralPath $python)) {
    throw "Project virtual environment not found. Create it and install build-requirements.txt first."
}
if (-not $innoCompiler) {
    throw "Inno Setup 6 was not found. Install Inno Setup 6, then rerun this script."
}

Push-Location $projectRoot
try {
    & $python -m PyInstaller --noconfirm --clean --onefile --windowed `
        --name "Gleek" --distpath "dist" --workpath "build\pyinstaller" `
        --specpath "build\pyinstaller" "main.py"
    if ($LASTEXITCODE -ne 0) {
        throw "PyInstaller failed with exit code $LASTEXITCODE."
    }

    & $innoCompiler "installer.iss"
    if ($LASTEXITCODE -ne 0) {
        throw "Inno Setup failed with exit code $LASTEXITCODE."
    }

    Write-Output "Installer created at $projectRoot\installer\Gleek-Setup-1.0.3.exe"
}
finally {
    Pop-Location
}
