# The RemoteControl UI rewrite, explained in full

This document covers every change between your original script and `remote_portal.py`: what the old code did, why it looked or behaved the way it did, what I replaced it with, and the reasoning. Where it matters I quote the old code next to the new code. The last sections are general front-end advice you can reuse, and an honest list of what is still imperfect.

I ran the new version offscreen only (it starts, logs in, and switches tabs without errors). I have not seen the animations on a real display, so judge the "feel" yourself and use the tuning table at the end to adjust it.

## Contents

1. [Summary: old vs new](#1-summary-old-vs-new)
2. [Bugs in the original that made it look "off"](#2-bugs-in-the-original-that-made-it-look-off)
3. [Design decisions: why it no longer looks generated](#3-design-decisions-why-it-no-longer-looks-generated)
4. [The core technique: custom painting instead of stylesheets](#4-the-core-technique-custom-painting-instead-of-stylesheets)
5. [Smooth motion: how and why](#5-smooth-motion-how-and-why)
6. [The cursor light (`Glow` mixin)](#6-the-cursor-light-glow-mixin)
7. [Component by component](#7-component-by-component)
8. [The animated background (`Stage`)](#8-the-animated-background-stage)
9. [Page transitions (`FadeStack`)](#9-page-transitions-fadestack)
10. [Layout, typography, and copywriting](#10-layout-typography-and-copywriting)
11. [Behavior and logic fixes](#11-behavior-and-logic-fixes)
12. [Performance notes](#12-performance-notes)
13. [What is still bad or unfinished](#13-what-is-still-bad-or-unfinished)
14. [General front-end advice](#14-general-front-end-advice)
15. [Tuning cheat sheet](#15-tuning-cheat-sheet)

---

## 1. Summary: old vs new

| Area | Original | Rewrite | Why it matters |
|---|---|---|---|
| Styling method | Qt stylesheets (QSS) re-set from code | Custom `paintEvent` with `QPainter` | Stylesheets can't do cursor-following light, and re-applying them every frame is slow |
| Button glow | New `QGraphicsDropShadowEffect` created on every animation tick | Radial gradient painted inside the button, positioned at the cursor | No object churn, and the light actually follows the mouse |
| Input focus animation | `setStyleSheet()` called every frame, with a hard threshold (`value > 0.1`) | Interpolated colors painted directly | The old one snapped at a threshold; the new one fades continuously |
| Timing | Fixed per-frame increments and fixed durations | Delta-time, exponential easing | Same speed on any machine; no jerky starts and stops |
| Background | Bouncing dots in a fixed 1100×700 area, probably hidden by opaque widgets | Drifting light blobs, wrapped particles, links between nearby particles and to the cursor | Looks alive and related to the product (a network of machines) |
| Selectors | Unscoped rules such as `QFrame {…}` and bare `setStyleSheet("background…; border…")` | Almost no stylesheets; the one global rule is scoped to `QLabel` | The old rules leaked into child labels and boxed them |
| Navigation | Buttons switch pages instantly; no active state; Settings did nothing | Fade transitions, a sliding highlight, working Settings page | Spatial continuity and no dead ends |
| Palette | Orange on near-black | Blue-tinted graphite with one seafoam accent | Orange on black is the most common generated look |
| Icons | Emoji in button text | None; text labels and painted vector marks | Emoji render differently on every OS and look unserious |
| Login failure | Modal `QMessageBox` | Inline message plus borders fading to red | Modals interrupt the flow |
| Window | Fixed 1100×700 | Resizable with a minimum size | Layouts adapt instead of breaking |
| DB path | Hard-coded `D:\` path that crashes if the folder is missing | Creates the folder; falls back to the script's folder | Prevents a startup crash |

---

## 2. Bugs in the original that made it look "off"

These are specific defects, not matters of taste. Several of them are why the old UI looked amateurish even when the colors were fine.

### 2.1 Stylesheet leakage (boxes inside boxes)

**Original (login card):**

```python
self.login_card.setStyleSheet(f"""
    QFrame {{
        background-color: rgba(15, 15, 15, 240);
        border-radius: 30px;
        border: 1px solid {BORDER_COLOR};
    }}
""")
```

**What is wrong:** `QLabel` inherits from `QFrame` in Qt. A rule written for `QFrame` therefore also matches every `QLabel` inside the card. The title and subtitle each received their own dark background, a 1px border, and a 30px radius. That produces faint outlined pills around text.

**Original (sidebar and device rows):**

```python
self.sidebar.setStyleSheet(f"background-color: {SIDEBAR_BG}; border-right: 1px solid {BORDER_COLOR};")
...
row.setStyleSheet(f"background-color: #111111; border-radius: 15px; border: 1px solid {BORDER_COLOR}; margin-bottom: 10px;")
```

**What is wrong:** A stylesheet set with no selector applies to the widget and all of its descendants. So the logo label got a right border, and every label in a device row got its own background, border, radius, and margin. Rows looked like cards containing more small cards.

**Fix:** The rewrite paints the card, sidebar, and row surfaces itself, so there is nothing to cascade. The single stylesheet that remains is deliberately narrow:

```python
app.setStyleSheet("QLabel{background:transparent;}")
```

**Rule to remember:** a bare `setStyleSheet("property: value")` on a container is almost always a bug. Use an `#objectName` or class selector, or paint it yourself.

### 2.2 The animated background was probably invisible

**Original:**

```python
self.setStyleSheet(f"background-color: {DEEP_BLACK}; color: {TEXT_WHITE};")  # on QMainWindow
self.bg_anim = AnimatedBackground(self)
self.bg_anim.lower()
...
self.central_widget = QWidget()          # created after, sits on top
self.setCentralWidget(self.central_widget)
```

**What is wrong:** The unscoped window stylesheet cascades down to the central widget and pages, so they paint an opaque `#050505` over the particle layer. `lower()` puts the particles at the bottom of the stack. The most likely result is that the animation ran at 60 fps and was never seen. It was also hard-coded to 1100×700, so it could not follow a resized window.

**Fix:** The backdrop is now the central widget itself (`Stage`), and everything else is a transparent child laid on top of it. Pages have no background fill, so the animation shows through, and cards use partial transparency so it shows through them too.

### 2.3 Hover was half-animated, half-snapping

**Original:**

```python
QPushButton:hover {
    background-color: ...;
    border: 1px solid {CLAUDE_ORANGE};
}
```

plus a separately animated shadow.

**What is wrong:** The `:hover` rule flips color and border instantly. The glow eases over 300 ms. The mismatch reads as "snappy", which you specifically asked to avoid.

**Fix:** All hover state is a number between 0 and 1 that eases toward its target, and every color is interpolated from that number.

### 2.4 The input focus animation was effectively a switch

**Original:**

```python
@border_alpha.setter
def border_alpha(self, value):
    self._border_alpha = value
    self.update_style(value > 0.1)   # boolean!

def update_style(self, focused):
    border_c = CLAUDE_ORANGE if focused else BORDER_COLOR
    self.setStyleSheet(...)
```

**What is wrong:** There are two problems.
1. The animated value is collapsed to a boolean by `value > 0.1`, so the border color jumps once, about 10% into the animation. The remaining 90% of the animation changes nothing visible.
2. `setStyleSheet` re-parses and re-polishes the widget. Doing that on every animation frame is expensive.

**Fix:** The border color is `mix(BORDER, ACCENT, focus)` where `focus` is a continuous 0..1 value, and it is painted directly with `QPainter`. There is no stylesheet work during animation.

### 2.5 New graphics effect every frame

**Original:**

```python
def update_glow(self):
    self.shadow = QGraphicsDropShadowEffect()
    ...
    self.setGraphicsEffect(self.shadow)
```

**What is wrong:** `update_glow` runs on every step of the 300 ms animation (and once at construction). Each call allocates a new effect and destroys the previous one. A drop-shadow effect also forces the widget to render offscreen and be blurred. Shadows also get clipped by the widget's rectangle, so glow cannot extend outside a button that sits in a tight layout.

**Fix:** The glow is drawn inside the widget's own paint event. No effect objects are created.

### 2.6 Smaller problems

- **Emoji in labels** (`"🏠  Dashboard"`): they render as different glyph sets on Windows, macOS, and Linux, mismatch the font weight, and align inconsistently.
- **Every device looked identical:** `Status: Online | IP: 192.168.1.100` repeated. Real data varies, and repeated identical strings make a UI look like a placeholder.
- **Logout did not log out:** it switched pages but kept `current_user` and left the typed credentials in the fields.
- **Settings did nothing:** the button had no handler and no page.
- **No active state on navigation:** you could not tell which page you were on.
- **Enter key did not submit** the login form.
- **`QMessageBox.warning` for a bad password:** a blocking system dialog with the OS look breaks the visual language.
- **Fixed window size:** `setFixedSize(1100, 700)` disables resizing and maximizing.
- **Unused imports:** `QPalette`, `QRect`, `QLinearGradient`, `QSequentialAnimationGroup`.
- **Database path:** `DB_FILE = "D:\\Remote Desktop App\\users_db.json"` raises an exception on first run if that folder does not exist.
- **Plaintext passwords** in the JSON file (still the case, see section 13).

---

## 3. Design decisions: why it no longer looks generated

"Vibe-coded" usually does not come from one bad choice. It comes from defaults stacked on top of each other. These are the specific tells I removed.

### 3.1 The color palette

**Before:**

```python
CLAUDE_ORANGE = "#D97757"
DEEP_BLACK = "#050505"
DARK_BG = "#0A0A0A"
```

Terracotta orange on pure near-black is the single most common AI-generated look right now. It also happens to be a well-known brand accent, so it reads as borrowed rather than chosen.

**After:**

```python
BG_TOP, BG_BOT = "#0B0F14", "#0E151D"     # graphite with a faint blue tint
SURFACE, SURF_HI = "#121A23", "#18222D"   # two surface levels
INPUT_BG, BORDER = "#0E141B", "#223040"
TEXT, MUTED, INK = "#E8EDF2", "#8595A8", "#06201B"
ACCENT, BLUE, AMBER, ERR = "#7DD3C0", "#4F7CFF", "#F2B872", "#F0707A"
```

Why this is better:
- **Tinted neutrals.** Every dark color has a bit of blue in it, so the greys feel related to each other. Pure `#111111` next to `#222222` feels flat and unrelated to the accent.
- **Named roles, not named colors.** `SURFACE`, `MUTED`, `INK` describe what the color does. `CLAUDE_ORANGE` describes where the color came from. When you want a different look, you change one constant.
- **One accent, one support color.** Seafoam is the accent for interactive things and focus. Blue appears only in the background light and the logo gradient. Amber and red are reserved for status and errors, so they keep their meaning.
- **`INK` for text on the accent.** Dark green text on a seafoam button has higher contrast than white text would. White on a light accent is a common legibility mistake.
- **Three text levels** (`TEXT`, `MUTED`, plus `INK`) instead of one gray (`TEXT_GRAY = "#666666"`), which on near-black is also too low in contrast to read comfortably.

### 3.2 Things I deliberately did not do

These are habits that mark a screen as generated, so I avoided them:

- All-caps tracked labels above headings (the original `Role: OWNER` tag was one).
- Small decorative labels above every title.
- Highlighting one word of a heading in the accent color.
- Fade-and-slide-up entrances on every section, and hover animations on everything for their own sake.
- Identical rounded cards, all with the same radius, chopped out of every section.
- Numbered markers (`01 / 02 / 03`) on content that is not a sequence.
- Arrows appended to button text.

### 3.3 Restrained motion

Motion is used for two purposes:
1. **Answering something the user did:** hover, press, focus, navigate, error.
2. **One deliberate moment:** the window fades in at startup, and the stat numbers count up when you reach the dashboard.

Everything else is ambient and slow (the background). Nothing bounces, flashes, or pulses for attention except the online status dot, where "alive" is the information being communicated.

### 3.4 Varied radii and hierarchy

The old UI used one `border-radius` (12–30px) wherever a box existed. The rewrite uses radius as hierarchy:

| Element | Radius |
|---|---|
| Buttons and inputs | 12 |
| Device rows and stat cards | 14 to 16 |
| Login card | 24 |
| Avatar | fully round |

Larger containers get larger radii, so the nesting looks intentional.

---

## 4. The core technique: custom painting instead of stylesheets

This is the biggest architectural change, so it is worth understanding.

### 4.1 Why stylesheets could not do what you asked

Qt stylesheets are good for static looks. They cannot express:
- A **radial gradient centered on the cursor position.** QSS gradients are fixed to the widget geometry.
- A **border whose brightness varies along its length** depending on where the light is.
- **Continuously interpolated state.** QSS has `:hover` and `:focus`, which are on/off. There is no transition support.
- **Ripples** that expand from the click point.

And each call to `setStyleSheet` makes Qt re-parse and re-apply (re-polish) the style, which is far too heavy for 60 updates per second.

### 4.2 The pattern used instead

Each interactive widget:
1. Holds small numbers describing its current visual state (`_hov`, `_prs`, `_lvl`, `_foc`...), each between 0 and 1.
2. Eases those numbers toward targets once per frame.
3. Overrides `paintEvent` and draws itself from those numbers using `QPainter`.

```python
fill = mix(SURF_HI, "#243242", self._hov)       # color is a function of hover
border = mix(BORDER, "#35485C", self._hov)
```

Because the state is continuous, every visual property moves in sync.

### 4.3 Painting details that matter

- **Antialiasing:** `p.setRenderHint(QPainter.RenderHint.Antialiasing)` on every painter. Without it, rounded corners look jagged.
- **Half-pixel insets:** shapes are inset by about 1 px (`.adjusted(1, 1, -1, -1)`) so a 1 px border is not clipped at the widget edge.
- **`QPainterPath` for shapes:** the same rounded-rectangle path is used for the fill, the border, the glow, and the ripple clip, so they all agree on the exact outline.
- **`p.setOpacity(0.4)` for disabled state:** one line dims the whole button, text included.

### 4.4 Painting a gradient border

```python
g = QRadialGradient(pos, R * 0.9)
g.setColorAt(0, alpha(self.glow_color, border * k))
g.setColorAt(1, alpha(self.glow_color, 0))
p.setPen(QPen(QBrush(g), 1.4))
p.drawPath(path)
```

A pen can use a gradient brush. The stroke is bright near the cursor and fades to transparent farther away along the same outline. This is what produces the "edge lights up where the mouse is" effect.

---

## 5. Smooth motion: how and why

### 5.1 The easing function

```python
def smooth(cur, target, dt, rate):
    return cur + (target - cur) * (1 - math.exp(-dt * rate))
```

This moves `cur` a fraction of the remaining distance toward `target` each frame.

**Why not the usual `value += 0.1` every frame?**
- A fixed step is tied to frame rate. On a slower machine or a dropped frame, animation speeds change.
- A constant-speed step starts and stops abruptly, which reads as mechanical.

**Why the `exp` form?**
- `dt` is the actual time since the previous frame, so the speed in real time is identical at 30, 60, or 144 fps.
- Motion is fastest at the beginning and gently decelerates into the target. This is how physical objects settle, and it is what people read as "smooth".
- It is interruptible: if the target changes mid-motion (cursor leaves, then comes back), the value simply starts heading to the new target from wherever it is, with no jump.

`rate` controls how snappy it feels. About 3 is floaty, about 8 is responsive, about 16 is quick. The values I used:

| What | Rate | Feel |
|---|---|---|
| Background cursor light | 2.6 | Lazy, trails behind the mouse |
| Proximity glow level | 6 | Gentle fade in and out |
| Hover fill | 9 | Responsive but soft |
| Press depth | 16 | Quick, so the click feels immediate |
| Glow position tracking | 12 | Follows the mouse with a slight lag |

### 5.2 Delta-time clamping

```python
dt = min(now - self.last, 0.05)
```

If the window is dragged or the app stalls, `dt` could be large, and everything would jump. Clamping to 50 ms keeps a hiccup from becoming a visual leap.

### 5.3 Easing curves for property animations

Where a fixed duration is more natural than continuous chasing (page fades, the sidebar highlight), I used `QPropertyAnimation` with named curves:

| Animation | Duration | Curve | Why |
|---|---|---|---|
| Page fade out | 220 ms | `InCubic` | Starts gently, accelerates away |
| Page fade in | 420 ms | `OutCubic` | Arrives fast then settles |
| Startup fade in | 700 ms | `OutCubic` | Slower, since it is the first impression |
| Sidebar highlight slide | 520 ms | `OutQuint` | Long, soft landing, so the highlight glides rather than jumps |
| Stat count-up | 1100 ms | `OutCubic` | Numbers race up then slow near the final value |

Rules of thumb used: **leaving should be shorter than arriving**, and **ease-out for things that appear, ease-in for things that leave**. Linear easing is almost never right for UI.

---

## 6. The cursor light (`Glow` mixin)

This implements "glowing light following the mouse if it passes any button".

### 6.1 Structure

`Glow` is a plain Python mixin (not a `QWidget`) that holds the shared logic. Buttons, inputs, and cards inherit from both a Qt class and `Glow`:

```python
class GlowButton(QPushButton, Glow): ...
class AnimatedInput(QLineEdit, Glow): ...
class Card(QFrame, Glow): ...
```

The Qt base class must come first, and the mixin deliberately has no `__init__` (it exposes `_glow_init()` instead). That avoids cooperative-constructor problems between PyQt and plain Python classes.

### 6.2 One ticker for everything

**Rejected approach:** give every widget its own `QTimer`. With a dozen widgets that is a dozen timers that fire at slightly different moments.

**Used approach:** each glow widget registers itself in a `weakref.WeakSet` called `LIVE`. The background (`Stage`) has the only timer, and each tick it:
1. Reads the global cursor position once.
2. Calls `glow_tick(dt, cursor)` on every visible registered widget.
3. Repaints the background.

Benefits: one timing source, everything in the same frame stays in sync, and the cursor is read once.

A `WeakSet` means widgets that Python deletes unregister themselves. Widgets whose C++ object was deleted while a Python wrapper still exists (for example device rows removed with `deleteLater()`) can raise `RuntimeError`, which is caught in the ticker.

### 6.3 Reading the cursor globally

```python
cur = QCursor.pos()
p = self.mapFromGlobal(cur)
```

The old code relied on `enterEvent` and `leaveEvent`, which only fire when the pointer is inside the widget. Reading the global cursor lets the light react **before** the pointer arrives. Moving the mouse toward a button makes it start glowing, which feels responsive and alive rather than reactive.

### 6.4 Proximity math

```python
dx = max(r.left() - p.x(), 0, p.x() - r.right())
dy = max(r.top()  - p.y(), 0, p.y() - r.bottom())
near = max(0.0, 1 - math.hypot(dx, dy) / self.glow_radius) ** 1.6
```

- `dx` and `dy` are the distance from the cursor to the nearest edge of the widget (zero if inside). This gives true distance to a rectangle, not to its center, so wide buttons glow properly along their length.
- `1 - distance / radius` is 1 when touching and 0 at `glow_radius` pixels away.
- `** 1.6` bends the curve so the glow stays subtle at a distance and ramps up near the widget. A linear falloff looks flat.
- The result (`near`) is a target. The actual `_lvl` chases it with `smooth(...)`, so the glow fades rather than switches.

Per-widget `glow_radius`: buttons 130, inputs 110, cards 200. Large cards need a larger range or the effect only appears at the edge.

### 6.5 Glow position tracking and snap

```python
if self._lvl < 0.01:
    self._gx, self._gy = p.x(), p.y()          # invisible: teleport
else:
    self._gx, self._gy = smooth(self._gx, p.x(), dt, 12), ...
```

While the glow is invisible, its position snaps to the cursor so it never visibly slides in from a stale location. Once visible, the position is eased, so the light has a soft trailing quality instead of being glued to the pointer.

### 6.6 Drawing

`paint_glow` draws two layers using the same path:
1. A **radial gradient fill** centered on the glow position (a soft pool of light on the surface).
2. A **gradient-stroked border** (the edge lighting).

Both fade to fully transparent at the radius, with alpha scaled by `_lvl * glow_strength`. Buttons use a stronger fill; cards use a weaker one so large surfaces don't wash out.

### 6.7 Only repaint when something is changing

```python
if busy or self._ripples or max(self._lvl, self._hov, self._prs) > 0.003:
    self.update()
```

A widget that is at rest and far from the cursor requests no repaint. Without this check, every widget would repaint 60 times per second forever.

---

## 7. Component by component

### 7.1 `GlowButton`

**Original:** `QPushButton` styled by QSS with a drop shadow that appears on hover.

**Rewrite:** fully custom-painted with three kinds: `primary`, `secondary`, `nav`.

Painted every frame from state:

| State | Effect | Detail |
|---|---|---|
| Hover (`_hov`) | Lift | Moves up by up to 1.2 px (`translated(0, -1.2 * self._hov ...)`) |
| Hover | Fill and border lightening | `mix()` between rest and hover colors |
| Press (`_prs`) | Press-in | Shrinks the rectangle by up to 1.5 px on each side and shifts down 0.6 px |
| Press | Ripple | A circle expands from the click point, ease-out cubic, fading as it grows |
| Proximity (`_lvl`) | Cursor light | Radial fill and border light (section 6) |
| Disabled | 40% opacity | `p.setOpacity(0.4)` |

Why these details:
- **Lift on hover plus press-in on click** gives a button physical depth. The two together say "this is a thing you can push".
- **The ripple** starts exactly where the click happened, so the feedback is tied to the user's action.
- **Primary buttons** use a white glow instead of the accent, because an accent glow on an accent button is invisible.
- **Nav buttons** have no fill. Their text color eases from `MUTED` to `TEXT` by `max(hover, active)`, and the highlight behind them comes from the sidebar (7.6).

The click ripple is added in `mousePressEvent`:

```python
def mousePressEvent(self, e):
    self._ripples.append((e.position().x(), e.position().y(), 0.0))
    super().mousePressEvent(e)
```

Each ripple is a tuple `(x, y, age)`. `glow_tick` increases the age and drops ripples older than 0.8 s.

### 7.2 `AnimatedInput`

**Original:** QSS border color swapped by a boolean.

**Rewrite:**

```python
def paintEvent(self, e):
    p = QPainter(self)
    ...                      # draw background, halo, border, glow
    p.end()
    super().paintEvent(e)    # let Qt draw the text, cursor, selection
```

- The widget's own stylesheet makes Qt's drawing transparent (`background:transparent; border:none`), so only text, caret, and selection come from Qt. The shape and borders come from my painter.
- `p.end()` before `super().paintEvent(e)` is required, because two painters cannot be active on the same widget at once.
- **Focus** eases `_foc` between 0 and 1: border goes from `BORDER` to `ACCENT`, and a 3 px low-alpha halo fades in outside it.
- **Error** eases `_err`: border goes toward `ERR`. The error state clears as soon as you type (`textChanged`).
- **Cursor light** works here too, at a lower strength, so the whole form feels like one interactive surface.

### 7.3 `Card`

A rounded surface painted with `alpha(SURFACE, 0.84)`, which is partially transparent, so the animated background shows through faintly. This gives depth without a blur effect (Qt has no cheap backdrop blur).

It takes a radius and a glow strength, so the login card, stat cards, device rows, and settings card are all the same class with different parameters. That keeps the components consistent without repetition.

### 7.4 `StatCard` and the count-up

```python
self.anim = QVariantAnimation(self)
self.anim.setDuration(1100)
self.anim.setEasingCurve(QEasingCurve.Type.OutCubic)
self.anim.valueChanged.connect(lambda v: self.value.setText(str(int(round(v)))))
```

When you reach the dashboard, the numbers count from 0 to their value. It is the one orchestrated "moment" on that screen, and it communicates that the data was just loaded. It re-runs when you return to the Dashboard tab (`nav()` schedules `count_up` 300 ms later, after the fade finishes).

### 7.5 `StatusDot`

```python
ph = (time.perf_counter() % 2.6) / 2.6
p.drawEllipse(ctr, 3.5 + 4 * ph, 3.5 + 4 * ph)      # expanding ring
```

Online devices show a slow ring expanding from the dot (2.6 s per pulse, fading out as it grows). Idle and offline dots are static, so animation itself carries meaning: only "online" is alive. The dot is registered with `LIVE` so the shared ticker repaints it.

### 7.6 `Sidebar` and the sliding highlight

**Original:** no indication of the current page.

**Rewrite:** the sidebar paints a highlight behind the active button, and the highlight's Y position is an animated `pyqtProperty`:

```python
indY = pyqtProperty(float, get_y, set_y)
self._anim = QPropertyAnimation(self, b"indY", self)   # 520 ms, OutQuint
```

When you click a different item, the highlight **glides** to it instead of one item turning off and another turning on. That spatial motion tells the user where they went. The sidebar also repositions the highlight in `resizeEvent` (unless an animation is running), so it stays aligned if the window changes size.

The highlight is a soft accent tint plus a 3 px bar on the left edge, which is a clear but quiet "selected" signal.

### 7.7 `LogoMark` and `Avatar`

Both are painted as vectors (`QLinearGradient` plus shapes), not loaded from image files:
- No external assets to ship or lose.
- Crisp at any DPI scaling.
- The logo is a ring and a dot (a target or connection point), which suits a remote-access tool.
- The avatar shows the user's initial on an accent-to-blue gradient.

### 7.8 `text()` helper

```python
def text(s, size, weight=QFont.Weight.Normal, color=TEXT):
```

Every label goes through one helper. That centralizes the type scale, so sizes and weights are chosen from a short list and not typed out inconsistently in 20 places.

---

## 8. The animated background (`Stage`)

`Stage` is the central widget. It paints the background and owns the single timer.

### 8.1 Layers, back to front

1. **Base:** vertical gradient `BG_TOP → BG_BOT`.
2. **Three large light blobs:** big radial gradients in blue and seafoam at low alpha (0.07 to 0.15). Each moves on a slow sine and cosine path:

   ```python
   c = QPointF(w * (fx + .10 * math.sin(t * sp + ph)),
               h * (fy + .10 * math.cos(t * sp * .8 + ph)))
   ```

   Sine on X and cosine at a slightly different speed on Y trace a slow wandering loop that never repeats exactly. Speeds of 0.06 to 0.11 rad/s mean one cycle takes roughly a minute or more, so it reads as atmosphere and not movement.
3. **Cursor light:** a 300 px soft radial glow that follows the mouse with heavy lag (rate 2.6).
4. **Links** between particles within 140 px of each other, and between particles and the cursor within 170 px. Line alpha falls with distance.
5. **Particles:** 38 dots whose alpha gently breathes (`sin(t * 1.1 + phase)`).

The links are the part chosen for this product: a field of nodes that connect when close looks like machines on a network, and the cursor "connecting" to nodes matches what the app does.

### 8.2 Differences from the original

| Original | Rewrite |
|---|---|
| Hard-coded 1100×700 bounds | Uses the actual widget size |
| Particles bounce off walls (`vx *= -1`) | Particles wrap around edges with modulo, so there is no visible reversal |
| Orange dots at varying alpha | Seafoam dots, links, and light blobs for depth |
| Flat black behind | Gradient base and moving light |
| Probably covered by opaque widgets | Is the root widget; everything else is transparent |

Wrapping uses modulo with a 20 px margin:

```python
q[0] = (q[0] + q[2] * dt + 20) % (w + 40) - 20
```

Particles leave and re-enter just off-screen, so no popping is visible.

### 8.3 Cost

The pair loop is O(n²). With 38 particles that is 703 pairs per frame, which is fine in Python. Going to 100 particles would be about 5,000 pairs per frame and start to hurt.

---

## 9. Page transitions (`FadeStack`)

`FadeStack` subclasses `QStackedWidget`. `fade_to(widget)` runs:

1. Fade the whole stack out (220 ms, `InCubic`).
2. Swap the current widget.
3. Fade back in (420 ms, `OutCubic`).

Used for login ↔ app and for tab switching.

### 8.4 Key implementation detail: the opacity effect is temporary

```python
def fin():
    if b >= 1: self.setGraphicsEffect(None)
```

A `QGraphicsOpacityEffect` makes Qt render the widget into an offscreen buffer, even at 100% opacity. With the cursor light repainting widgets constantly, that would mean re-rendering the whole page offscreen every frame. So an effect is created for each transition and removed as soon as opacity returns to 1.

### 8.5 Interruption handling

If you click another tab mid-transition, the running animation is stopped and a new fade starts from the current opacity (`self.graphicsEffect().opacity()`), so no flash back to full opacity occurs.

---

## 10. Layout, typography, and copywriting

### 10.1 Login layout

**Original:** a centered card with a title, a subtitle, two inputs, and a button. The most common login screen layout there is.

**Rewrite:** split composition. The brand (logo, name, and one sentence) sits left, and the sign-in card sits right and is vertically centered. It gives the screen a point of view and fills a wide window better.

### 10.2 Type scale

| Use | Size | Weight |
|---|---|---|
| Brand wordmark | 44 | DemiBold |
| Page titles | 32 | DemiBold |
| Login card title | 28 | DemiBold |
| Stat numbers | 34 | DemiBold |
| Card heading, device name | 15 to 16 | DemiBold |
| Body, subtitles | 14 to 15 | Normal |
| Secondary data (IP, status) | 13 | Normal in `MUTED` |

Hierarchy comes from three things only: **size, weight, and color** (white versus muted). No underlines, no all-caps, no mixed typefaces.

Font selection:

```python
f.setFamilies(["Segoe UI Variable Text", "Segoe UI", "Inter", "SF Pro Text", "Helvetica Neue", "Arial"])
```

`setFamilies` is a fallback list, so Windows 11, Windows 10, macOS, and Linux each pick the best available font. The original forced `"Segoe UI"`, which silently falls back to something random on non-Windows systems.

### 10.3 Spacing

Spacing comes in a few repeated values (6, 12, 14, 18, 22 to 26, 48) instead of arbitrary numbers. Related things sit close together (title and subtitle at 6 px), and unrelated groups are separated (26 px before the stat cards). Page margins are a generous 48 px.

### 10.4 Copywriting

| Original | Rewrite | Reason |
|---|---|---|
| "Welcome Back" | "Sign in" | Says what the screen is for |
| "Enter your credentials to manage devices" | "Use your admin account to manage devices." | Plain words, no jargon |
| "Invalid username or password" (modal) | "That username and password don't match." (inline) | Says what went wrong, near the field, and does not block |
| "Welcome, Owner" | "Good evening, Owner" (by local time) | Small human touch |
| "Role: OWNER" in orange caps | "Access level" stat card showing "Owner" | Removes the decorative caps label |
| `Device ID: Dev-1 | Status: Online | IP: 192.168.1.100` | Separate dot, name, status, IP columns | Scannable, not one long string |
| "Connect" | "Connect" → "Connecting…" → "Connected" | The same action keeps the same name through the flow |
| "Logout" | "Sign out" | Matches "Sign in" |

Sentence case throughout. Buttons say what they do ("Open devices", "Sign in").

---

## 11. Behavior and logic fixes

- **Logout** clears `self.user`, empties both fields, and fades back to login.
- **Enter submits** on both inputs.
- **Whitespace** in the username is trimmed (`.strip()`).
- **`.get()` lookup:** `self.db.get("users", {}).get(u)` replaces `username in users and users[username]["password"] == password`, so a missing user can never raise `KeyError`.
- **Settings page** exists and shows the signed-in user and role.
- **Active nav state** is tracked and reset to Dashboard on every sign-in.
- **DB path robustness:** `os.makedirs(..., exist_ok=True)` and a fallback to a file next to the script.
- **Device statuses** now vary (online, idle, offline); the Connect button is disabled for offline devices.
- **Counts are computed** from the user's visible devices (`n_total`, `n_online`) instead of being static.
- **Lambda late-binding handled:**

  ```python
  b.clicked.connect(lambda _, b=b: self.connect_device(b))
  ```

  Without `b=b`, every lambda created in a loop would reference the final value of `b`. The default argument captures the current one.
- **Safe delayed callbacks:** `connect_device` wraps its `QTimer.singleShot` callback in `try/except RuntimeError`, because the row might be deleted (user switched account) before the timer fires.
- **Dark title bar** on Windows via `DwmSetWindowAttribute` (attribute 20). Wrapped in `try/except`, so it does nothing on other systems. Without it, a bright white OS title bar sits on top of a dark app, which looks unfinished.

---

## 12. Performance notes

What was done to keep it light:

| Decision | Benefit |
|---|---|
| One shared timer, not per-widget timers | Fewer wakeups, one synchronized frame |
| Widgets skip `update()` when at rest | Idle widgets cost nothing |
| Cursor read once per frame | No redundant calls |
| Opacity effects removed after transitions | No permanent offscreen rendering |
| No stylesheet changes at runtime | No re-polishing |
| No drop-shadow effects | No blur passes |
| Delta-time clamp | Stalls don't snowball |
| Hidden widgets skipped (`isVisible()`) | Pages that are not shown cost nothing |
| About 38 particles | Link loop stays small |

---

## 13. What is still bad or unfinished

Being direct about the weak points:

1. **Not visually verified on a real screen.** I tested that it runs and navigates, offscreen. Motion timing and glow intensity should be judged by eye. Use section 15 to tune.
2. **No keyboard focus ring on buttons.** Mouse feedback is rich, but tabbing through buttons shows no visible focus indicator. Inputs do show focus. Adding a focus outline in `GlowButton.paintEvent` when `self.hasFocus()` would fix this.
3. **No "reduce motion" option.** Some users need less animation. A setting that disables the particles and shortens transitions would be good practice.
4. **The whole window repaints every frame.** That is fine on a desktop, but it uses constant CPU even when idle. If this runs on a weak machine or must stay open all day, lower the background timer to 30 fps (`timer.start(33)`), or pause it when the window is minimized or inactive.
5. **Python timers are not vsync-locked.** A `QTimer` at 16 ms can show slight jitter. For perfect frame pacing you would move the background to a `QOpenGLWidget` or a Qt Quick/QML scene. That is a larger rewrite.
6. **Hover detection is geometric.** It checks whether the cursor is inside the widget's rectangle, so it ignores another window or widget overlapping it. This is not a problem in this layout.
7. **The opacity effect during fades** can make text look very slightly softer while a transition is running. It is gone once the fade ends.
8. **Plaintext passwords** in the JSON file. Fine for a mock, not for real use. Store salted hashes (for example `hashlib.scrypt` or `bcrypt`) and compare in constant time (`hmac.compare_digest`).
9. **Mock data.** `DEVICES` and the Connect behavior are placeholders to hook your real logic into.
10. **Everything is in one file.** It is easier to share but not how you would ship a larger app. The natural split would be `theme.py`, `widgets.py`, `stage.py`, and `app.py`.
11. **Fixed pixel sizes** (for example the login card is 410×480, the sidebar is 250 wide). They look right at normal DPI but a very small window would feel cramped. The minimum window size of 1000×660 protects against that.

---

## 14. General front-end advice

These apply to any desktop or web UI.

**1. Make state continuous, not binary.**
Instead of `hovered: bool`, keep `hover: float 0..1` and derive every property from it. This single habit is the biggest difference between a UI that feels smooth and one that feels switchy.

**2. Animate with time, not frames.**
Use delta-time and an easing function. Never `x += 5` per tick.

**3. Ease out for arriving, ease in for leaving, never linear.**
And keep exits shorter than entrances (220 ms out, 420 ms in).

**4. Keep response to input immediate and the motion after it soft.**
Press feedback should start instantly (rate 16). The glow that follows can be slow (rate 6). Immediate feedback and slow settling is what feels both responsive and luxurious.

**5. Give every interactive element at least three states** with visible differences: rest, hover, pressed. Add focus and disabled.

**6. Motion should explain, not decorate.**
The sidebar highlight slides because it shows where you went. The dot pulses because online means alive. If you cannot say what a motion communicates, remove it.

**7. Use one accent color and let neutrals do the rest.**
Reserve other colors for meaning (error, warning). Tint your neutrals toward the accent's hue.

**8. Build a small token set** (colors, radii, spacing, type sizes) and use only those. Inconsistent values are the first thing that makes an interface feel amateur.

**9. Hierarchy from size, weight, and contrast, not decoration.**
If you reach for a border, a background, or a caps label to separate things, first try changing spacing or weight.

**10. Different radii for different levels.**
Nested shapes should have radii that make geometric sense (an inner radius is the outer radius minus the padding).

**11. Never block the user for an error you can show inline.**
Show it near the cause, in plain words, say what happened, and clear it as soon as they start fixing it.

**12. Avoid emoji as icons.**
Use drawn vectors, an icon font, or SVG. Or just use text.

**13. Scope your selectors.**
In Qt: use `#objectName` or specific class selectors, and remember `QLabel` is a `QFrame`. In CSS: avoid naked element selectors for visual properties on containers.

**14. Fake data should look real.**
Vary values. Identical rows read as a template.

**15. Write for the person using it.**
Name actions by what happens ("Open devices"), keep the same name for the same action through a flow, use sentence case, and make empty and error states say what to do next.

**16. Restraint.**
Choose one memorable thing (here, the cursor light and the living background) and keep everything else quiet. When a screen feels busy, remove one effect.

**17. Respect performance.**
Know which operations are expensive (stylesheet changes, graphics effects, offscreen rendering) and keep them out of per-frame code.

---

## 15. Tuning cheat sheet

All values you might want to change, and where they live in `remote_portal.py`.

| I want... | Change this |
|---|---|
| Different accent color | `ACCENT` (and `INK` for text on it) |
| Warmer or cooler background | `BG_TOP`, `BG_BOT`, `SURFACE`, `BORDER` |
| Glow that starts further from a button | `glow_radius` in `Glow` (default 130) |
| Stronger or weaker glow | `glow_strength`, or the `fill` and `border` arguments in `paint_glow` calls |
| Glow that trails more | Lower the `12` in `smooth(self._gx, ..., 12)` |
| Glow that fades slower | Lower the `6` in `smooth(self._lvl, near, dt, 6)` |
| Snappier hover | Raise the `9` in `smooth(self._hov, ..., 9)` |
| Less button lift | The `1.2` in `translated(0, -1.2 * self._hov ...)` |
| Slower ripple | The `0.8` (seconds) in `glow_tick` and `paintEvent` |
| Slower page transitions | `220` and `420` in `FadeStack` |
| Slower sidebar highlight | `setDuration(520)` in `Sidebar` |
| Cursor light lag in background | The `2.6` in `Stage.tick` |
| Busier or calmer background | Particle count `range(38)`, blob alphas, particle speed `uniform(-9, 9)` |
| Lower CPU use | `self.timer.start(33)` for roughly 30 fps |
| Remove cursor-to-particle lines | Delete the second `if self.mx is not None:` block in `Stage.paintEvent` |
| Different greeting or copy | `enter_app`, `page_dash`, `page_devices` |
| Real devices | Replace `DEVICES` and implement `connect_device` |
